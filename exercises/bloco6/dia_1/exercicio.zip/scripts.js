function estados(){

    let estados = ["Acre","Alagoas","Amapá","Amazonas","Bahia","Ceará","Distrito Federal","Espírito Santo","Goiás","Maranhão","Mato Grosso","Mato Grosso do Sul","Minas Gerais","Pará","Paraíba","Paraná","Pernambuco","Piauí","Rio de Janeiro","Rio Grande do Norte","Rio Grande do Sul","Rondônia"]
    let pegaestado = document.querySelector("#estados")
    

    for(let index = 0 ; index < estados.length ; index++){

        let criaelemento = document.createElement("option")
        
        criaelemento.innerHTML = estados[index]
        
        pegaestado.appendChild(criaelemento)
    }


}
estados()